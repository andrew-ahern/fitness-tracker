# FitLog

Personal diet and fitness tracker — a Progressive Web App (PWA).

## Files

```
fitlog/
├── index.html      — the entire app (HTML + CSS + JavaScript)
├── manifest.json   — PWA metadata (name, icons, display mode)
├── sw.js           — service worker (offline support, caching)
├── icon-192.png    — home screen icon (192×192) — add your own
├── icon-512.png    — home screen icon (512×512) — add your own
└── README.md       — this file
```

## How to deploy (GitHub Pages — free)

1. Create a free account at github.com
2. Create a new repository called `fitlog` (public)
3. Upload all files in this folder to the repository
4. Go to Settings → Pages → Source: Deploy from branch → main → / (root)
5. GitHub will give you a URL like: https://yourusername.github.io/fitlog
6. Open that URL in Safari on your iPhone
7. Tap the Share button → "Add to Home Screen"
8. FitLog now appears on your home screen like a native app

## How to update the app

1. Edit index.html (or other files) on your computer
2. Upload the changed file(s) to GitHub
3. Open the app URL in Safari and hard-refresh (pull down to refresh)
4. The app updates automatically — your data is preserved

## Data storage

- All data is stored locally in Safari's localStorage on your device
- Nothing is sent to any server
- Export your data regularly via Settings → Export
- Save exports to iCloud Drive for safekeeping

## Build plan

- [x] Step 1 — Skeleton: data model, storage, navigation, export/import
- [ ] Step 2 — Logging forms: all five log types
- [ ] Step 3 — Charts: all visualisations
- [ ] Step 4 — PWA polish: icons, offline behaviour
- [ ] Step 5 — Review and refinement
